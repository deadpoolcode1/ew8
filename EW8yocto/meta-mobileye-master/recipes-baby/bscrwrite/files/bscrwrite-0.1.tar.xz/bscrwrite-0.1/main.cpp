#include <iostream>
#include <fcntl.h>
#include <getopt.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <linux/ioctl.h>
#include <linux/spi/spidev.h>
#include <sys/ioctl.h>
#include <stdlib.h>

#include <sys/mman.h>
#include <fcntl.h>
#include <errno.h>



using namespace std;

#define AT91C_BASE_SECURAM  0xf8044000

#define        AT91C_BASE_SYSC         0xf8048000

#define AT91C_BASE_BSC_CR   (AT91C_BASE_SYSC + 0x54)

static int bscr_write(void);
static int bureg3_write(void);

//Write Bscr:
#define BSC_CR_WPKEY_Pos 16
#define BSC_CR_WPKEY_Msk (0xffffu << BSC_CR_WPKEY_Pos)
#define BSC_CR_WPKEY (0x6683 << 16)

#if 0
typedef struct {
  unsigned int BUSRAM_LOWER[1024]; /**< \brief (Securam Offset: 0x0000) Lower 4KB auto-erased */
  unsigned int BUSRAM_HIGHER[256]; /**< \brief (Securam Offset: 0x1000) Higher 1KB not auto-erased */
  unsigned int BUREG[8];           /**< \brief (Securam Offset: 0x1400) BUREG 256 bits auto-erased */
} Securam;
#endif

static int bscr_write(void)
{

    unsigned int valueBSC_CR = 0x00000007;//VALID,BUREG3


    int fd = open("/dev/mem", O_RDWR);

    /* Map one page of memory that contains the BSC
       control register */
    void* ptr = mmap(NULL, 4096, PROT_READ|PROT_WRITE,
                     MAP_SHARED, fd, AT91C_BASE_SYSC);
    close(fd);

    if(ptr == (void *)-1)
    {
        printf("mmap failed\n");
        return 0;
    }

    volatile unsigned* bsc_cr = (unsigned*)(ptr + 0x54);


    printf("BOOT value old is %u\n", *bsc_cr);

    /* Write the new BOOT value */
    *bsc_cr = (valueBSC_CR & ~BSC_CR_WPKEY_Msk) | BSC_CR_WPKEY;
    printf("BOOT value set to %u\n", *bsc_cr);

    munmap(ptr, 4096);


    return 0;


    /* Output example information */



    /*
    Securam *securam = (Securam*)AT91C_BASE_SECURAM;
    printf("Writing 0x%08x to BUREG3\n",
           (unsigned int)valueBSC_CR);
    securam->BUREG[3] = valueBUREG3;
    */
}
//End of write bscr


static int bureg3_write(void)
{
    unsigned int valueBUREG3 = 0x00040cf0;//BUREG3 boot to Sam-ba monitor


    int fd = open("/dev/mem", O_RDWR);

    /* Map one page of memory that contains the BSC
       control register */
    void* ptr = mmap(NULL, 6144, PROT_READ|PROT_WRITE,
                     MAP_SHARED, fd, AT91C_BASE_SECURAM);
    close(fd);

    if(ptr == (void *)-1)
    {
        printf("mmap failed\n");
        return 0;
    }

    volatile unsigned * BUREG = (unsigned*)(ptr + 0x1400);

    printf("Bureg3 old value:0x%08x\n", BUREG[3]);

    printf("Writing 0x%08x to BUREG3\n",
           (unsigned int)valueBUREG3);
    BUREG[0] = 0x0;
    BUREG[1] = 0x0;
    BUREG[2] = 0x0;
    BUREG[3] = valueBUREG3;


    munmap(ptr, 4096);


    return 0;


    /* Output example information */



    /*
    Securam *securam = (Securam*)AT91C_BASE_SECURAM;
    printf("Writing 0x%08x to BUREG3\n",
           (unsigned int)valueBSC_CR);
    securam->BUREG[3] = valueBUREG3;
    */
}
//End of write bscr

int main(void)
{
    bscr_write();
    bureg3_write();
}
