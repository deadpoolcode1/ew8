#include <iostream>
#include <fcntl.h>
#include <getopt.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <linux/ioctl.h>
#include <linux/spi/spidev.h>
#include <sys/ioctl.h>
#include <stdlib.h>

#include <sys/mman.h>
#include <fcntl.h>
#include <errno.h>

#include <drm/drm.h>
#include <drm/drm_mode.h>
#include <xf86drm.h>
#include <xf86drmMode.h>
#include <drm_fourcc.h>

#include <time.h>
#include <inttypes.h>
#include <signal.h>


#include <QDebug>
#include <QFile>
#include <QDataStream>



int drm_fd;
void * drm_fb_map;
quint32 drm_map_fb_size;

void sighandler(qint32 signum);



using namespace std;

int main(void)
{
    quint32 plane_id = 35;
    quint32 crtc_id = 37;
 #if 0
    quint32 conn_id = 28;
#endif
    quint32 fb_id;
    quint32 width = 320;
    quint32 height = 240;

    qint32 input_size = 0;

    struct drm_mode_create_dumb creDumb;
    struct drm_mode_map_dumb mapDumb;
    struct drm_mode_destroy_dumb desDumb;

    signal(SIGUSR1, sighandler);
    signal(SIGUSR2, sighandler);

    memset(& creDumb ,  0, sizeof(creDumb));
    memset(& mapDumb ,  0, sizeof(mapDumb));
    memset(& desDumb ,  0, sizeof(desDumb));

    drm_fd = open("/dev/dri/card0", O_RDWR| O_CLOEXEC);


    if(drm_fd != -1)
    {

        quint32 plane_flags = 0;

        creDumb.width = width;
        creDumb.height = height;
        creDumb.bpp = 24;



        if(drmIoctl(drm_fd, DRM_IOCTL_MODE_CREATE_DUMB, & creDumb))
        {
             qDebug() << "Failed to create dump:" << QString(strerror(errno));
        }



        drm_map_fb_size = creDumb.size;
        quint32 pitch = creDumb.pitch;
        quint32 handle = creDumb.handle;

        if (drmModeAddFB(drm_fd, width, height, 24, 24, pitch, handle, &fb_id))
        {
            qDebug() << "Failed to add fb:" << QString(strerror(errno));
            close(drm_fd);
            exit(0);
        }


        mapDumb.handle = handle;

        qint32 mapDumbStatus = drmIoctl(drm_fd, DRM_IOCTL_MODE_MAP_DUMB, &mapDumb);

        if(mapDumbStatus)
        {
            qDebug() <<  "Failed to dumb drm buffer:" <<
                         QString(strerror(errno));

        }

        qDebug() << "FB size: " << (quint32)drm_map_fb_size;


        qDebug() << "FB Offset: " << (quint64)mapDumb.offset;

#if 1
       if (drmModeSetPlane(drm_fd, plane_id, crtc_id, fb_id,
                           plane_flags, 0, 0, width, height,
                           0, 0, width << 16, height << 16)) {
           qDebug() <<  "Failed to enable plane:" <<
                        QString(strerror(errno));
       }
#endif

        drm_fb_map = mmap(0, drm_map_fb_size, PROT_READ|PROT_WRITE, MAP_SHARED, drm_fd, mapDumb.offset);





        if(drm_fb_map ==  MAP_FAILED)
        {
            qDebug("Mapping of frame buffer area failed");
        }
        else
        {
            //NOTE:  read file from stdin

            qint32 remaining_size = drm_map_fb_size;
            do
            {


                input_size =  read(0, (void*)((char*)drm_fb_map + (drm_map_fb_size-remaining_size)), drm_map_fb_size);
                remaining_size -=input_size;
                qDebug() << "size of read bytes of splash:" << input_size << " remains:" << remaining_size;
            }
            while(remaining_size);
        }


        sleep(15);

        //TODO check availability:

         qDebug() << "ew8_splash: drop DRM master and clear the screen";

        drmDropMaster(drm_fd);
        memset(drm_fb_map, 0x00, drm_map_fb_size);
        munmap(drm_fb_map, drm_map_fb_size);
        close(drm_fd);
    }

    return 0;
}

void sighandler(qint32 signum)
{
    int ret = 0;

    if (signum == SIGUSR1)
    {
        drmDropMaster(drm_fd);
        qDebug() << "ew8_splash: DRM master dropped by signal";
        sleep(15);
    }

    if (signum == SIGUSR2)
    {
        qDebug() << "ew8_splash: Clear the screen by signal";
        memset(drm_fb_map, 0x00, drm_map_fb_size);
        munmap (drm_fb_map, drm_map_fb_size);
        close(drm_fd);

        exit(ret);
    }
}

