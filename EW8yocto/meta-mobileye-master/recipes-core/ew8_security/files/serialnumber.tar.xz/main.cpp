#include <QFile>
#include <QTextStream>
#include <QJsonObject>
#include <QJsonArray>

#ifndef WIN32
//TODO remove unused:
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <linux/ioctl.h>
#include <sys/ioctl.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <errno.h>
#include <iostream>
#endif




#define	AT91C_BASE_SFC	0xf804c000
#define	AT91C_BASE_PMC	0xf0014000

#define	AT91C_SFC_DR0_OFFSET (0x20)
#define	AT91C_PMC_PCR_OFFSET (0x10c)

//Fuse Controller ID:
#define	AT91C_ID_SFC 50
#define	AT91C_PMC_PCR_EN (1 << 28)
#define	AT91C_PMC_PCR_CMD (1 << 12)

void enableDisableSFC(quint32* wr_ptr, bool On);
quint32 readDataSFC(quint32* rd_ptr, quint32 index);
void readServiceNumber(void);

quint8 SN_data[16] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

int main(int argc, char *argv[])
{
   readServiceNumber();

   std::cout << "sn: ";
   for (size_t i = 0; i<16; i++)
   {
       if(SN_data[i] < 0x10)
       {
            std::cout << 0;
       }
       std::cout << std::hex  << (quint32)SN_data[i] << " ";
   }
   std::cout << std::endl;
}



void readServiceNumber(void)
{
    //TODO read the SN and verify:
    qint32 mem_fd = open("/dev/mem",O_RDWR);

    void* pmc_pcr_ptr = mmap(NULL, AT91C_PMC_PCR_OFFSET + sizeof(quint32), PROT_WRITE,
                        MAP_PRIVATE, mem_fd, AT91C_BASE_PMC);


    void* sfc_dr_ptr = mmap(NULL, AT91C_SFC_DR0_OFFSET + 16*sizeof(quint32), PROT_READ,
                        MAP_PRIVATE, mem_fd, AT91C_BASE_SFC);



    close(mem_fd);


    enableDisableSFC((quint32*)(pmc_pcr_ptr)+(AT91C_PMC_PCR_OFFSET/sizeof(quint32)),true);


    quint32 readRegister;
    quint32 emptyRegisters = 0;
    quint8 byteLSB;
    bool regIntegrity = true;

    for(qint32 i = 0; i<16 && regIntegrity;i++)
    {
        readRegister = readDataSFC((quint32*)sfc_dr_ptr+(AT91C_SFC_DR0_OFFSET/sizeof(quint32)),i);


        byteLSB = (quint8)(readRegister & 0xff);

        if(0 == readRegister)
        {
            emptyRegisters++;
        }
        else
        {
            quint8 byteMSB = (quint8)((readRegister >> 010)& 0xff);

            regIntegrity = (byteLSB == (quint8)(~ byteMSB));
        }

            SN_data[i] = byteLSB;
    }

    enableDisableSFC((quint32*)(pmc_pcr_ptr)+(AT91C_PMC_PCR_OFFSET/sizeof(quint32)),false);

    if(!regIntegrity | ((0 != emptyRegisters) && (16 != emptyRegisters)))
    {
        for(qint32 i = 0; i<16;i++)
        {
             SN_data[i] = 0xff;
        }
    }

    munmap(sfc_dr_ptr, AT91C_SFC_DR0_OFFSET + 16*sizeof(quint32));

    munmap(pmc_pcr_ptr, AT91C_PMC_PCR_OFFSET + sizeof(quint32));
}

void enableDisableSFC(quint32* wr_ptr, bool On)
{
    *wr_ptr = On ? (AT91C_ID_SFC | AT91C_PMC_PCR_CMD | AT91C_PMC_PCR_EN) :
                   (AT91C_ID_SFC | AT91C_PMC_PCR_CMD);
}

quint32 readDataSFC(quint32* rd_ptr, quint32 index)
{
   quint32 ret;
   ret = *(rd_ptr+index);
   return ret;
}
